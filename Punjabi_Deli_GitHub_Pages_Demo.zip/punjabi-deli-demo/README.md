# Punjabi Deli — Unofficial Restaurant Website Demo

A mobile-responsive, static HTML/CSS/JavaScript portfolio concept. Not affiliated with or endorsed by Punjabi Deli.

## Publish on GitHub Pages (Android)
1. Sign in at https://github.com and create a **public** repository named `punjabi-deli-demo`.
2. Tap **Add file → Upload files** and upload `index.html`, `style.css`, and `script.js` from the extracted ZIP. Commit changes.
3. Go to **Settings → Pages → Build and deployment**. Choose **Deploy from a branch**, branch `main`, folder `/(root)`, then **Save**.
4. Your website should appear at `https://YOUR-USERNAME.github.io/punjabi-deli-demo/` after deployment.

The sample menu and prices are invented for design demonstration and should not be treated as actual restaurant offerings. The Google Maps link is a search link, not a verified listing. No order processing, WhatsApp contact, or forms are enabled.
